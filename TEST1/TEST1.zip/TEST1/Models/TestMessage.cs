﻿namespace TEST1.Models
{
    public class TestMessage
    {
        public int Id { get; set; }
        public string? Content { get; set; }
    }
}
